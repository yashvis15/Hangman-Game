import random

def welcome():
    name = input("Welcome to the Hangman Game! What is your name?").capitalize()

    if name.isalpha():
        print("Hi", name, ", you will play against the computer. Good Luck!")
    else:
        print("Please enter your name using letters only.")
        name = input("Enter your game name here:   ")
        print("Hi", name, ", the rules of the game are written below.")

def play_again():
    response = input("Would you like to play again? Enter Y for Yes and N for No").lower()
    if response == 'y':
        game_run()
    else:
        print("See you soon! Thanks for playing.")

def get_word():
    words = ['Python', 'cat', 'chair', 'plant', 'table', 'house', 'school', 'computer', 'keyboard', 'mouse', 'screen', 'monitor', 'printer', 'laptop']
    return random.choice(words).lower()

def game_run():
    welcome()
    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    word = get_word()
    letters_guessed = []
    tries = 7
    guessed = False
    print()
    print("The word contains", len(word), "letters.")
    print('_ ' * len(word))

    while not guessed and tries > 0:
        print('You have', tries, 'tries.')
        guess = input('Please enter one letter or the full word: ').lower()

        if len(guess) == 1:
            if guess not in alphabet:
                print("You must enter a letter.")
            elif guess in letters_guessed:
                print('You have already guessed that letter. Please try another one.')
            elif guess not in word:
                print('Sorry, that letter is not in the word.')
                letters_guessed.append(guess)
                tries -= 1
            else:
                print('Good guess! The letter is in the word.')
                letters_guessed.append(guess)
        elif len(guess) == len(word):
            if guess == word:
                print('Great job! You have guessed the word.')
                guessed = True
            else:
                print('Sorry, that is not the word we are looking for.')
                tries -= 1
        else:
            print('The length of your guess is not the same as the length of the word we are looking for.')
            tries -= 1

        status = ''
        for letter in word:
            if letter in letters_guessed:
                status += letter + ' '
            else:
                status += '_ '

        print(status)

        if status.replace(" ", "") == word:
            print('Congrats! You guessed the word.')
            guessed = True
        elif tries == 0:
            print("Oops, sorry, you ran out of tries. The word was", word)

    play_again()

game_run()
